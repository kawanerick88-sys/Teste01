"use client";

import { useEffect, useState, use } from "react";
import Link from "next/link";
import { useRouter, useParams } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sparkles, ArrowLeft, Save, Eye, Download, Settings, Plus, Trash2, Copy, GripVertical, Type, Image as ImageIcon, Square, Layout, ChevronDown, Loader2, Globe, Check, X, Undo, Redo } from "lucide-react";

interface Block {
  id: string;
  type: string;
  content: Record<string, any>;
  styles: Record<string, any>;
}

interface Project {
  id: string;
  name: string;
  status: string;
  published_url: string | null;
  json_state: {
    blocks: Block[];
  };
  theme_config: {
    colors: Record<string, string>;
    fonts: Record<string, string>;
  };
}

const blockTypes = [
  { type: "hero", name: "Hero", icon: Layout },
  { type: "text", name: "Texto", icon: Type },
  { type: "image", name: "Imagem", icon: ImageIcon },
  { type: "button", name: "Botão", icon: Square },
  { type: "features", name: "Features", icon: Layout },
  { type: "contact", name: "Contato", icon: Square },
];

const defaultBlockContent: Record<string, Record<string, any>> = {
  hero: {
    title: "Título do seu site",
    subtitle: "Seu subtítulo aqui",
    cta: "Saiba mais",
    ctaLink: "#",
  },
  text: {
    content: "Adicione seu texto aqui. Clique para editar.",
  },
  image: {
    src: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=800&q=80",
    alt: "Imagem",
    caption: "",
  },
  button: {
    text: "Clique aqui",
    link: "#",
  },
  features: {
    title: "Nossos Recursos",
    items: [
      { title: "Recurso 1", description: "Descrição do recurso 1" },
      { title: "Recurso 2", description: "Descrição do recurso 2" },
      { title: "Recurso 3", description: "Descrição do recurso 3" },
    ],
  },
  contact: {
    title: "Fale Conosco",
    email: "contato@exemplo.com",
    phone: "(00) 00000-0000",
  },
};

export default function EditorPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [selectedBlock, setSelectedBlock] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [history, setHistory] = useState<{ blocks: Block[] }[]>([]);
  const [historyIndex, setHistoryIndex] = useState(-1);
  const [settingsOpen, setSettingsOpen] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/auth?redirect=dashboard");
    }
  }, [user, authLoading, router]);

  useEffect(() => {
    if (user && id) {
      fetchProject();
    }
  }, [user, id]);

  const fetchProject = async () => {
    try {
      const { data, error } = await supabase
        .from("projects")
        .select("*")
        .eq("id", id)
        .eq("user_id", user?.id)
        .maybeSingle();

      if (error) throw error;
      if (data) {
        setProject(data);
        if (data.json_state?.blocks?.length > 0) {
          setHistory([{ blocks: data.json_state.blocks }]);
          setHistoryIndex(0);
        }
      } else {
        router.push("/dashboard");
      }
    } catch (err) {
      console.error("Error fetching project:", err);
      router.push("/dashboard");
    } finally {
      setLoading(false);
    }
  };

  const saveProject = async () => {
    if (!project) return;

    setSaving(true);
    try {
      const { error } = await supabase
        .from("projects")
        .update({
          json_state: { blocks: project.json_state.blocks },
          theme_config: project.theme_config,
        })
        .eq("id", project.id);

      if (error) throw error;
    } catch (err) {
      console.error("Error saving project:", err);
    } finally {
      setSaving(false);
    }
  };

  const addToHistory = (blocks: Block[]) => {
    const newHistory = history.slice(0, historyIndex + 1);
    newHistory.push({ blocks: JSON.parse(JSON.stringify(blocks)) });
    setHistory(newHistory);
    setHistoryIndex(newHistory.length - 1);
  };

  const undo = () => {
    if (historyIndex > 0) {
      setHistoryIndex(historyIndex - 1);
      setProject({
        ...project!,
        json_state: { blocks: JSON.parse(JSON.stringify(history[historyIndex - 1].blocks)) },
      });
    }
  };

  const redo = () => {
    if (historyIndex < history.length - 1) {
      setHistoryIndex(historyIndex + 1);
      setProject({
        ...project!,
        json_state: { blocks: JSON.parse(JSON.stringify(history[historyIndex + 1].blocks)) },
      });
    }
  };

  const addBlock = (type: string) => {
    if (!project) return;

    const newBlock: Block = {
      id: Date.now().toString(),
      type,
      content: { ...defaultBlockContent[type] },
      styles: {},
    };

    const newBlocks = [...project.json_state.blocks, newBlock];
    setProject({
      ...project,
      json_state: { blocks: newBlocks },
    });
    setSelectedBlock(newBlock.id);
    addToHistory(newBlocks);
  };

  const updateBlockContent = (blockId: string, content: Record<string, any>) => {
    if (!project) return;

    const newBlocks = project.json_state.blocks.map((block) =>
      block.id === blockId ? { ...block, content: { ...block.content, ...content } } : block
    );

    setProject({
      ...project,
      json_state: { blocks: newBlocks },
    });
  };

  const updateBlockStyles = (blockId: string, styles: Record<string, any>) => {
    if (!project) return;

    const newBlocks = project.json_state.blocks.map((block) =>
      block.id === blockId ? { ...block, styles: { ...block.styles, ...styles } } : block
    );

    setProject({
      ...project,
      json_state: { blocks: newBlocks },
    });
  };

  const deleteBlock = (blockId: string) => {
    if (!project) return;

    const newBlocks = project.json_state.blocks.filter((block) => block.id !== blockId);
    setProject({
      ...project,
      json_state: { blocks: newBlocks },
    });
    setSelectedBlock(null);
    addToHistory(newBlocks);
  };

  const duplicateBlock = (block: Block) => {
    if (!project) return;

    const newBlock: Block = {
      ...JSON.parse(JSON.stringify(block)),
      id: Date.now().toString(),
    };

    const index = project.json_state.blocks.findIndex((b) => b.id === block.id);
    const newBlocks = [...project.json_state.blocks];
    newBlocks.splice(index + 1, 0, newBlock);

    setProject({
      ...project,
      json_state: { blocks: newBlocks },
    });
    addToHistory(newBlocks);
  };

  const publishProject = async () => {
    if (!project) return;

    setPublishing(true);
    try {
      // Save first
      await saveProject();

      // Generate published URL
      const slug = project.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
      const publishedUrl = `${slug}.swiftly.app`;

      const { error } = await supabase
        .from("projects")
        .update({
          status: "published",
          published_url: publishedUrl,
          slug,
        })
        .eq("id", project.id);

      if (error) throw error;

      setProject({
        ...project,
        status: "published",
        published_url: publishedUrl,
      });
    } catch (err) {
      console.error("Error publishing project:", err);
    } finally {
      setPublishing(false);
    }
  };

  const exportHTML = () => {
    if (!project) return;

    let html = `<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${project.name}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: Inter, system-ui, sans-serif; background: #0a0a0f; color: #fff; }
    .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
    .block { padding: 40px 20px; }
    .hero { text-align: center; padding: 80px 20px; }
    .hero h1 { font-size: 3rem; margin-bottom: 16px; }
    .hero p { font-size: 1.25rem; color: #9ca3af; margin-bottom: 24px; }
    .btn { display: inline-block; padding: 12px 24px; background: linear-gradient(to right, #7c3aed, #2563eb); color: #fff; text-decoration: none; border-radius: 8px; }
    .text-block { max-width: 800px; margin: 0 auto; line-height: 1.8; }
    .image-block img { max-width: 100%; border-radius: 8px; }
    .features { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 24px; }
    .feature { background: #1f2937; padding: 24px; border-radius: 8px; }
    .contact { text-align: center; background: #1f2937; border-radius: 8px; }
  </style>
</head>
<body>
  <div class="container">`;

    project.json_state.blocks.forEach((block) => {
      switch (block.type) {
        case "hero":
          html += `
    <div class="block hero">
      <h1>${block.content.title || ""}</h1>
      <p>${block.content.subtitle || ""}</p>
      <a href="${block.content.ctaLink || "#"}" class="btn">${block.content.cta || "Saiba mais"}</a>
    </div>`;
          break;
        case "text":
          html += `
    <div class="block text-block">
      <p>${block.content.content || ""}</p>
    </div>`;
          break;
        case "image":
          html += `
    <div class="block image-block">
      <img src="${block.content.src || ""}" alt="${block.content.alt || ""}">
      ${block.content.caption ? `<p style="text-align: center; color: #9ca3af; margin-top: 8px;">${block.content.caption}</p>` : ""}
    </div>`;
          break;
        case "button":
          html += `
    <div class="block" style="text-align: center;">
      <a href="${block.content.link || "#"}" class="btn">${block.content.text || "Clique aqui"}</a>
    </div>`;
          break;
        case "features":
          html += `
    <div class="block features">
      ${(block.content.items || []).map((item: any) => `
        <div class="feature">
          <h3>${item.title || ""}</h3>
          <p style="color: #9ca3af; margin-top: 8px;">${item.description || ""}</p>
        </div>
      `).join("")}
    </div>`;
          break;
        case "contact":
          html += `
    <div class="block contact">
      <h2>${block.content.title || "Fale Conosco"}</h2>
      <p style="margin-top: 16px;">${block.content.email || ""}</p>
      <p>${block.content.phone || ""}</p>
    </div>`;
          break;
      }
    });

    html += `
  </div>
  <footer style="text-align: center; padding: 20px; color: #6b7280; border-top: 1px solid #374151; margin-top: 40px;">
    <p>Feito com Swiftly</p>
  </footer>
</body>
</html>`;

    // Download HTML file
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project.name.toLowerCase().replace(/\s+/g, "-")}.html`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading || authLoading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
      </div>
    );
  }

  if (!project) return null;

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex flex-col">
      {/* Header */}
      <header className="h-14 border-b border-white/5 bg-white/5 flex items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <Link href="/dashboard">
            <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <div className="w-px h-6 bg-white/10" />
          <span className="font-medium text-white truncate max-w-[200px]">{project.name}</span>
          {project.status === "published" && (
            <span className="px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-xs flex items-center gap-1">
              <Globe className="w-3 h-3" />
              Online
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" onClick={undo} disabled={historyIndex <= 0} className="text-gray-400 hover:text-white">
            <Undo className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={redo} disabled={historyIndex >= history.length - 1} className="text-gray-400 hover:text-white">
            <Redo className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setSettingsOpen(true)} className="text-gray-400 hover:text-white">
            <Settings className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={() => setShowPreview(!showPreview)} className="text-gray-400 hover:text-white">
            <Eye className="w-4 h-4" />
          </Button>
          <Button variant="ghost" size="icon" onClick={exportHTML} className="text-gray-400 hover:text-white">
            <Download className="w-4 h-4" />
          </Button>
          <Button variant="outline" onClick={saveProject} disabled={saving} className="border-white/10">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
            Salvar
          </Button>
          <Button onClick={publishProject} disabled={publishing} className="bg-gradient-to-r from-violet-600 to-blue-600">
            {publishing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Globe className="w-4 h-4 mr-2" />}
            Publicar
          </Button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar - Block Library */}
        <aside className="w-64 border-r border-white/5 bg-white/5 p-4 overflow-y-auto">
          <h3 className="text-sm font-medium text-gray-400 mb-3">Blocos</h3>
          <div className="grid grid-cols-2 gap-2">
            {blockTypes.map((block) => (
              <button
                key={block.type}
                onClick={() => addBlock(block.type)}
                className="flex flex-col items-center gap-2 p-3 rounded-lg bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all"
              >
                <block.icon className="w-5 h-5 text-gray-400" />
                <span className="text-xs text-gray-400">{block.name}</span>
              </button>
            ))}
          </div>
        </aside>

        {/* Canvas */}
        <main className="flex-1 overflow-y-auto p-8 bg-[#0a0a0f]">
          <div className="max-w-4xl mx-auto bg-[#0f1117] rounded-xl border border-white/10 min-h-[600px]">
            {project.json_state.blocks.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-[600px] text-gray-500">
                <Layout className="w-16 h-16 mb-4" />
                <p>Nenhum bloco ainda</p>
                <p className="text-sm">Adicione blocos na sidebar</p>
              </div>
            ) : (
              <div className="divide-y divide-white/5">
                {project.json_state.blocks.map((block) => (
                  <div
                    key={block.id}
                    onClick={() => setSelectedBlock(block.id)}
                    className={`relative group cursor-pointer transition-all ${selectedBlock === block.id ? "ring-2 ring-violet-500" : "hover:ring-1 hover:ring-white/20"}`}
                  >
                    {/* Block Actions */}
                    <div className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 z-10">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-8 h-8 bg-black/50 hover:bg-black/70"
                        onClick={(e) => { e.stopPropagation(); duplicateBlock(block); }}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-8 h-8 bg-black/50 hover:bg-red-900/70 text-red-400"
                        onClick={(e) => { e.stopPropagation(); deleteBlock(block.id); }}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>

                    {/* Block Render */}
                    <div className="p-8">
                      {block.type === "hero" && (
                        <div className="text-center py-12">
                          <h1
                            contentEditable
                            suppressContentEditableWarning
                            className="text-4xl font-bold mb-4 outline-none focus:ring-2 focus:ring-violet-500 rounded"
                            onBlur={(e) => updateBlockContent(block.id, { title: e.currentTarget.textContent || "" })}
                          >
                            {block.content.title}
                          </h1>
                          <p
                            contentEditable
                            suppressContentEditableWarning
                            className="text-xl text-gray-400 mb-6 outline-none focus:ring-2 focus:ring-violet-500 rounded"
                            onBlur={(e) => updateBlockContent(block.id, { subtitle: e.currentTarget.textContent || "" })}
                          >
                            {block.content.subtitle}
                          </p>
                          <button className="px-6 py-3 bg-gradient-to-r from-violet-600 to-blue-600 rounded-lg">
                            {block.content.cta}
                          </button>
                        </div>
                      )}

                      {block.type === "text" && (
                        <div className="max-w-2xl mx-auto">
                          <p
                            contentEditable
                            suppressContentEditableWarning
                            className="text-lg text-gray-300 leading-relaxed outline-none focus:ring-2 focus:ring-violet-500 rounded p-2"
                            onBlur={(e) => updateBlockContent(block.id, { content: e.currentTarget.textContent || "" })}
                          >
                            {block.content.content}
                          </p>
                        </div>
                      )}

                      {block.type === "image" && (
                        <div className="max-w-3xl mx-auto">
                          <img
                            src={block.content.src}
                            alt={block.content.alt}
                            className="w-full rounded-lg"
                          />
                          <input
                            type="text"
                            placeholder="URL da imagem"
                            value={block.content.src}
                            onChange={(e) => updateBlockContent(block.id, { src: e.target.value })}
                            className="mt-2 w-full bg-white/5 border border-white/10 rounded px-3 py-2 text-sm"
                          />
                          <p
                            contentEditable
                            suppressContentEditableWarning
                            className="text-center text-gray-500 mt-2 outline-none"
                            onBlur={(e) => updateBlockContent(block.id, { caption: e.currentTarget.textContent || "" })}
                          >
                            {block.content.caption}
                          </p>
                        </div>
                      )}

                      {block.type === "button" && (
                        <div className="text-center py-8">
                          <input
                            type="text"
                            value={block.content.text}
                            onChange={(e) => updateBlockContent(block.id, { text: e.target.value })}
                            className="text-center bg-transparent border-none text-xl font-medium outline-none focus:ring-2 focus:ring-violet-500 rounded px-2"
                          />
                          <input
                            type="text"
                            placeholder="Link"
                            value={block.content.link}
                            onChange={(e) => updateBlockContent(block.id, { link: e.target.value })}
                            className="mt-2 block w-full max-w-xs mx-auto bg-white/5 border border-white/10 rounded px-3 py-2 text-sm"
                          />
                        </div>
                      )}

                      {block.type === "features" && (
                        <div>
                          <h2
                            contentEditable
                            suppressContentEditableWarning
                            className="text-2xl font-bold text-center mb-8 outline-none"
                            onBlur={(e) => updateBlockContent(block.id, { title: e.currentTarget.textContent || "" })}
                          >
                            {block.content.title}
                          </h2>
                          <div className="grid md:grid-cols-3 gap-6">
                            {(block.content.items || []).map((item: any, index: number) => (
                              <div key={index} className="bg-white/5 rounded-lg p-6">
                                <h4
                                  contentEditable
                                  suppressContentEditableWarning
                                  className="font-semibold mb-2 outline-none"
                                  onBlur={(e) => {
                                    const newItems = [...block.content.items];
                                    newItems[index] = { ...item, title: e.currentTarget.textContent || "" };
                                    updateBlockContent(block.id, { items: newItems });
                                  }}
                                >
                                  {item.title}
                                </h4>
                                <p
                                  contentEditable
                                  suppressContentEditableWarning
                                  className="text-sm text-gray-400 outline-none"
                                  onBlur={(e) => {
                                    const newItems = [...block.content.items];
                                    newItems[index] = { ...item, description: e.currentTarget.textContent || "" };
                                    updateBlockContent(block.id, { items: newItems });
                                  }}
                                >
                                  {item.description}
                                </p>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {block.type === "contact" && (
                        <div className="text-center py-12 bg-white/5 rounded-lg">
                          <h2
                            contentEditable
                            suppressContentEditableWarning
                            className="text-2xl font-bold mb-4 outline-none"
                            onBlur={(e) => updateBlockContent(block.id, { title: e.currentTarget.textContent || "" })}
                          >
                            {block.content.title}
                          </h2>
                          <div className="space-y-2">
                            <input
                              type="email"
                              value={block.content.email}
                              onChange={(e) => updateBlockContent(block.id, { email: e.target.value })}
                              className="block w-full max-w-xs mx-auto bg-white/5 border border-white/10 rounded px-3 py-2 text-sm"
                            />
                            <input
                              type="tel"
                              value={block.content.phone}
                              onChange={(e) => updateBlockContent(block.id, { phone: e.target.value })}
                              className="block w-full max-w-xs mx-auto bg-white/5 border border-white/10 rounded px-3 py-2 text-sm"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </main>

        {/* Properties Panel */}
        {selectedBlock && (
          <aside className="w-72 border-l border-white/5 bg-white/5 p-4 overflow-y-auto">
            <h3 className="text-sm font-medium text-gray-400 mb-3">Propriedades</h3>
            {(() => {
              const block = project.json_state.blocks.find((b) => b.id === selectedBlock);
              if (!block) return null;

              return (
                <div className="space-y-4">
                  <div>
                    <label className="text-xs text-gray-500 mb-1 block">Tipo</label>
                    <div className="px-3 py-2 bg-white/5 rounded text-sm capitalize">{block.type}</div>
                  </div>

                  {block.type === "hero" && (
                    <>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Título</label>
                        <Input
                          value={block.content.title || ""}
                          onChange={(e) => updateBlockContent(block.id, { title: e.target.value })}
                          className="bg-white/5 border-white/10"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Subtítulo</label>
                        <Input
                          value={block.content.subtitle || ""}
                          onChange={(e) => updateBlockContent(block.id, { subtitle: e.target.value })}
                          className="bg-white/5 border-white/10"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Texto do Botão</label>
                        <Input
                          value={block.content.cta || ""}
                          onChange={(e) => updateBlockContent(block.id, { cta: e.target.value })}
                          className="bg-white/5 border-white/10"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Link do Botão</label>
                        <Input
                          value={block.content.ctaLink || ""}
                          onChange={(e) => updateBlockContent(block.id, { ctaLink: e.target.value })}
                          className="bg-white/5 border-white/10"
                        />
                      </div>
                    </>
                  )}

                  {block.type === "button" && (
                    <>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Texto</label>
                        <Input
                          value={block.content.text || ""}
                          onChange={(e) => updateBlockContent(block.id, { text: e.target.value })}
                          className="bg-white/5 border-white/10"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Link</label>
                        <Input
                          value={block.content.link || ""}
                          onChange={(e) => updateBlockContent(block.id, { link: e.target.value })}
                          className="bg-white/5 border-white/10"
                        />
                      </div>
                    </>
                  )}

                  {block.type === "image" && (
                    <>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">URL da Imagem</label>
                        <Input
                          value={block.content.src || ""}
                          onChange={(e) => updateBlockContent(block.id, { src: e.target.value })}
                          className="bg-white/5 border-white/10"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Alt</label>
                        <Input
                          value={block.content.alt || ""}
                          onChange={(e) => updateBlockContent(block.id, { alt: e.target.value })}
                          className="bg-white/5 border-white/10"
                        />
                      </div>
                    </>
                  )}

                  {block.type === "features" && (
                    <div>
                      <label className="text-xs text-gray-500 mb-1 block">Título da Seção</label>
                      <Input
                        value={block.content.title || ""}
                        onChange={(e) => updateBlockContent(block.id, { title: e.target.value })}
                        className="bg-white/5 border-white/10"
                      />
                    </div>
                  )}

                  {block.type === "contact" && (
                    <>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Título</label>
                        <Input
                          value={block.content.title || ""}
                          onChange={(e) => updateBlockContent(block.id, { title: e.target.value })}
                          className="bg-white/5 border-white/10"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Email</label>
                        <Input
                          type="email"
                          value={block.content.email || ""}
                          onChange={(e) => updateBlockContent(block.id, { email: e.target.value })}
                          className="bg-white/5 border-white/10"
                        />
                      </div>
                      <div>
                        <label className="text-xs text-gray-500 mb-1 block">Telefone</label>
                        <Input
                          value={block.content.phone || ""}
                          onChange={(e) => updateBlockContent(block.id, { phone: e.target.value })}
                          className="bg-white/5 border-white/10"
                        />
                      </div>
                    </>
                  )}

                  <Button
                    variant="destructive"
                    size="sm"
                    onClick={() => deleteBlock(block.id)}
                    className="w-full mt-4"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Excluir Bloco
                  </Button>
                </div>
              );
            })()}
          </aside>
        )}
      </div>

      {/* Settings Dialog */}
      <Dialog open={settingsOpen} onOpenChange={setSettingsOpen}>
        <DialogContent className="bg-[#0f1117] border-white/10">
          <DialogHeader>
            <DialogTitle className="text-white">Configurações do Projeto</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-300 mb-2 block">Nome do Projeto</label>
              <Input
                value={project.name}
                onChange={(e) => setProject({ ...project, name: e.target.value })}
                className="bg-white/5 border-white/10"
              />
            </div>

            <div>
              <label className="text-sm text-gray-300 mb-2 block">Cor Principal</label>
              <div className="flex gap-2">
                {["#7c3aed", "#2563eb", "#059669", "#dc2626", "#ea580c", "#4f46e5"].map((color) => (
                  <button
                    key={color}
                    onClick={() => setProject({ ...project, theme_config: { ...project.theme_config, colors: { ...project.theme_config.colors, primary: color } } })}
                    className={`w-8 h-8 rounded-full ${project.theme_config.colors?.primary === color ? "ring-2 ring-white" : ""}`}
                    style={{ backgroundColor: color }}
                  />
                ))}
              </div>
            </div>

            {project.status === "published" && project.published_url && (
              <div>
                <label className="text-sm text-gray-300 mb-2 block">URL Pública</label>
                <div className="flex items-center gap-2 p-3 bg-white/5 rounded">
                  <Globe className="w-4 h-4 text-green-400" />
                  <span className="text-sm text-green-400">{project.published_url}</span>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
