"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Sparkles, Plus, Layout, MoreVertical, Trash2, Copy, Edit, Globe, Loader2, LogOut } from "lucide-react";

interface Project {
  id: string;
  name: string;
  status: string;
  published_url: string | null;
  created_at: string;
  updated_at: string;
}

const templates = [
  { id: "1", name: "Negócio", category: "business", color: "from-blue-600 to-cyan-600" },
  { id: "2", name: "Portfólio", category: "portfolio", color: "from-purple-600 to-pink-600" },
  { id: "3", name: "Restaurante", category: "restaurant", color: "from-orange-600 to-red-600" },
  { id: "4", name: "Landing Page", category: "landing", color: "from-green-600 to-emerald-600" },
  { id: "5", name: "Barbearia", category: "barbershop", color: "from-zinc-600 to-zinc-800" },
  { id: "6", name: "Loja Virtual", category: "store", color: "from-pink-600 to-rose-600" },
];

export default function DashboardPage() {
  const { user, loading: authLoading, signOut } = useAuth();
  const router = useRouter();
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [newProjectName, setNewProjectName] = useState("");
  const [createLoading, setCreateLoading] = useState(false);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push("/auth?redirect=dashboard");
    }
  }, [user, authLoading, router]);

  useEffect(() => {
    if (user) {
      fetchProjects();
    }
  }, [user]);

  const fetchProjects = async () => {
    try {
      const { data, error } = await supabase
        .from("projects")
        .select("*")
        .eq("user_id", user?.id)
        .order("updated_at", { ascending: false });

      if (error) throw error;
      setProjects(data || []);
    } catch (err) {
      console.error("Error fetching projects:", err);
    } finally {
      setLoading(false);
    }
  };

  const createProject = async (templateId?: string) => {
    if (!user || !newProjectName.trim()) return;

    setCreateLoading(true);
    try {
      const { data, error } = await supabase
        .from("projects")
        .insert({
          user_id: user.id,
          name: newProjectName,
          template_id: templateId || null,
          json_state: {
            blocks: [
              {
                id: "1",
                type: "hero",
                content: {
                  title: newProjectName,
                  subtitle: "Seu subtítulo aqui",
                  cta: "Saiba mais",
                },
                styles: {},
              },
            ],
          },
          theme_config: {
            colors: {
              primary: "#7c3aed",
              secondary: "#2563eb",
            },
            fonts: {
              heading: "Inter",
              body: "Inter",
            },
          },
        })
        .select()
        .maybeSingle();

      if (error) throw error;

      setNewProjectName("");
      setCreateDialogOpen(false);
      setTemplateDialogOpen(false);

      if (data) {
        router.push(`/editor/${data.id}`);
      }
    } catch (err) {
      console.error("Error creating project:", err);
    } finally {
      setCreateLoading(false);
    }
  };

  const deleteProject = async (projectId: string) => {
    if (!confirm("Tem certeza que deseja excluir este projeto?")) return;

    try {
      const { error } = await supabase
        .from("projects")
        .delete()
        .eq("id", projectId);

      if (error) throw error;
      setProjects(projects.filter((p) => p.id !== projectId));
    } catch (err) {
      console.error("Error deleting project:", err);
    }
  };

  const duplicateProject = async (project: Project) => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from("projects")
        .insert({
          user_id: user.id,
          name: `${project.name} (cópia)`,
          template_id: project.template_id,
          json_state: project.json_state,
          theme_config: project.theme_config,
        })
        .select()
        .maybeSingle();

      if (error) throw error;
      if (data) {
        setProjects([data, ...projects]);
      }
    } catch (err) {
      console.error("Error duplicating project:", err);
    }
  };

  const createWithPrompt = () => {
    const prompt = sessionStorage.getItem("swiftly_prompt");
    if (prompt) {
      setNewProjectName(prompt.replace(/^(site para|landing page para|portfólio para)\s+/i, "").trim() || "Novo Projeto");
      sessionStorage.removeItem("swiftly_prompt");
    } else {
      setNewProjectName("Novo Projeto");
    }
    setTemplateDialogOpen(true);
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      {/* Header */}
      <header className="border-b border-white/5 bg-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-600 to-blue-600 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-white">Swiftly</span>
            </Link>

            <div className="flex items-center gap-4">
              <Link href="/templates">
                <Button variant="ghost" className="text-gray-300 hover:text-white">
                  Templates
                </Button>
              </Link>
              <Button
                variant="ghost"
                onClick={() => signOut()}
                className="text-gray-300 hover:text-white"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sair
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Meus Projetos</h1>
          <p className="text-gray-400">Gerencie e crie seus sites</p>
        </div>

        {/* Actions */}
        <div className="flex flex-wrap gap-4 mb-8">
          <Dialog open={templateDialogOpen} onOpenChange={setTemplateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-700 hover:to-blue-700">
                <Plus className="w-4 h-4 mr-2" />
                Novo Projeto
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-[#0f1117] border-white/10 text-white">
              <DialogHeader>
                <DialogTitle>Criar novo projeto</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-300">Nome do projeto</label>
                  <Input
                    value={newProjectName}
                    onChange={(e) => setNewProjectName(e.target.value)}
                    placeholder="Meu site..."
                    className="bg-white/5 border-white/10"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-gray-300">Escolher template (opcional)</label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    <button
                      onClick={() => createProject()}
                      className="p-4 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 transition-all text-left"
                    >
                      <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gray-600 to-gray-800 flex items-center justify-center mb-2">
                        <Layout className="w-4 h-4" />
                      </div>
                      <span className="text-sm">Em branco</span>
                    </button>
                    {templates.map((template) => (
                      <button
                        key={template.id}
                        onClick={() => createProject(template.id)}
                        className="p-4 rounded-lg bg-white/5 border border-white/10 hover:border-white/20 transition-all text-left"
                      >
                        <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${template.color} flex items-center justify-center mb-2`}>
                          <Layout className="w-4 h-4" />
                        </div>
                        <span className="text-sm">{template.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                <Button
                  onClick={() => createProject()}
                  disabled={!newProjectName.trim() || createLoading}
                  className="w-full bg-gradient-to-r from-violet-600 to-blue-600"
                >
                  {createLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    "Criar projeto"
                  )}
                </Button>
              </div>
            </DialogContent>
          </Dialog>

          <Link href="/templates">
            <Button variant="outline" className="border-white/10 hover:bg-white/10">
              <Layout className="w-4 h-4 mr-2" />
              Ver templates
            </Button>
          </Link>
        </div>

        {/* Projects Grid */}
        {projects.length === 0 ? (
          <Card className="bg-white/5 border-white/10">
            <CardContent className="flex flex-col items-center justify-center py-16">
              <Layout className="w-16 h-16 text-gray-600 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Nenhum projeto ainda</h3>
              <p className="text-gray-400 mb-6">Crie seu primeiro projeto para começar</p>
              <Button
                onClick={() => setTemplateDialogOpen(true)}
                className="bg-gradient-to-r from-violet-600 to-blue-600"
              >
                <Plus className="w-4 h-4 mr-2" />
                Criar projeto
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project) => (
              <Card key={project.id} className="bg-white/5 border-white/10 hover:border-white/20 transition-all group">
                <CardContent className="p-0">
                  {/* Preview */}
                  <div className="aspect-video bg-gradient-to-br from-violet-900/20 to-blue-900/20 rounded-t-lg flex items-center justify-center">
                    <Layout className="w-12 h-12 text-white/20" />
                  </div>

                  {/* Info */}
                  <div className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-semibold text-white">{project.name}</h3>
                        <p className="text-sm text-gray-500">
                          {new Date(project.updated_at).toLocaleDateString("pt-BR")}
                        </p>
                      </div>
                      <div className="flex items-center gap-1">
                        {project.status === "published" && (
                          <span className="px-2 py-1 rounded-full bg-green-500/20 text-green-400 text-xs">
                            <Globe className="w-3 h-3 inline mr-1" />
                            Online
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-2 mt-4">
                      <Link href={`/editor/${project.id}`} className="flex-1">
                        <Button variant="outline" size="sm" className="w-full border-white/10 hover:bg-white/10">
                          <Edit className="w-4 h-4 mr-2" />
                          Editar
                        </Button>
                      </Link>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => duplicateProject(project)}
                        className="text-gray-400 hover:text-white"
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => deleteProject(project.id)}
                        className="text-gray-400 hover:text-red-400"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
