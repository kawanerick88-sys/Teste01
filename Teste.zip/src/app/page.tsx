"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Sparkles, Zap, Palette, Globe, Code, ChevronRight, Check, Menu, X, LogOut, Layout, User } from "lucide-react";

const suggestions = [
  "Site para barbearia moderna",
  "Landing page para produto digital",
  "Portfólio para designer",
  "Site para restaurante",
  "Loja virtual de produtos",
  "Landing page para startup",
];

const benefits = [
  {
    icon: Zap,
    title: "Rápido e Intuitivo",
    description: "Crie seu site em segundos com IA. Sem complicação.",
  },
  {
    icon: Palette,
    title: "Totalmente Personalizável",
    description: "Edite cores, fontes, textos e layout como quiser.",
  },
  {
    icon: Globe,
    title: "Publicação Instantânea",
    description: "Publique com um clique. Seu site no ar imediatamente.",
  },
  {
    icon: Code,
    title: "Exporte Seu Código",
    description: "Baixe HTML, CSS e tenha controle total.",
  },
];

const steps = [
  {
    number: "01",
    title: "Escolha ou descreva",
    description: "Use um template pronto ou descreva o que você quer criar.",
  },
  {
    number: "02",
    title: "Edite como quiser",
    description: "Personalize textos, imagens e estilos no editor visual.",
  },
  {
    number: "03",
    title: "Publique",
    description: "Compartilhe seu site com o mundo em um clique.",
  },
];

const plans = [
  {
    name: "Free",
    price: "R$ 0",
    period: "/mês",
    description: "Perfeito para começar",
    features: [
      "3 projetos",
      "Templates básicos",
      "Subdomínio Swiftly",
      "Marca d'água no rodapé",
    ],
    cta: "Começar Grátis",
    popular: false,
  },
  {
    name: "Pro",
    price: "R$ 29",
    period: "/mês",
    description: "Para profissionais",
    features: [
      "Projetos ilimitados",
      "Templates premium",
      "Domínio personalizado",
      "Exportação de código",
      "Sem marca d'água",
      "Suporte prioritário",
    ],
    cta: "Assinar Pro",
    popular: true,
  },
];

export default function LandingPage() {
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, signOut } = useAuth();
  const router = useRouter();

  const handleGenerate = async () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);

    // Simulate AI generation
    await new Promise(resolve => setTimeout(resolve, 2000));

    // Store prompt in sessionStorage for the editor
    sessionStorage.setItem('swiftly_prompt', prompt);

    if (user) {
      router.push('/dashboard');
    } else {
      router.push('/auth?redirect=dashboard');
    }

    setIsGenerating(false);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#0a0a0f]/80 backdrop-blur-lg border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-600 to-blue-600 flex items-center justify-center">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-violet-400 to-blue-400 bg-clip-text text-transparent">
                Swiftly
              </span>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              <Link href="/templates" className="text-gray-300 hover:text-white transition-colors">
                Templates
              </Link>
              <Link href="#como-funciona" className="text-gray-300 hover:text-white transition-colors">
                Como funciona
              </Link>
              <Link href="#precos" className="text-gray-300 hover:text-white transition-colors">
                Preços
              </Link>
            </nav>

            <div className="hidden md:flex items-center gap-4">
              {user ? (
                <div className="flex items-center gap-4">
                  <Link href="/dashboard">
                    <Button variant="outline" className="border-white/20 hover:bg-white/10">
                      <Layout className="w-4 h-4 mr-2" />
                      Dashboard
                    </Button>
                  </Link>
                  <Button
                    variant="ghost"
                    onClick={() => signOut()}
                    className="text-gray-300 hover:text-white"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Sair
                  </Button>
                </div>
              ) : (
                <>
                  <Link href="/auth">
                    <Button variant="ghost" className="text-gray-300 hover:text-white">
                      Entrar
                    </Button>
                  </Link>
                  <Link href="/auth">
                    <Button className="bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-700 hover:to-blue-700">
                      Começar Grátis
                    </Button>
                  </Link>
                </>
              )}
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden p-2"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-[#0a0a0f] border-b border-white/5 p-4">
            <nav className="flex flex-col gap-4">
              <Link href="/templates" className="text-gray-300 hover:text-white py-2">
                Templates
              </Link>
              <Link href="#como-funciona" className="text-gray-300 hover:text-white py-2">
                Como funciona
              </Link>
              <Link href="#precos" className="text-gray-300 hover:text-white py-2">
                Preços
              </Link>
              <div className="flex gap-2 mt-4">
                {user ? (
                  <>
                    <Link href="/dashboard" className="flex-1">
                      <Button variant="outline" className="w-full border-white/20">
                        Dashboard
                      </Button>
                    </Link>
                    <Button variant="ghost" onClick={() => signOut()}>
                      <LogOut className="w-4 h-4" />
                    </Button>
                  </>
                ) : (
                  <Link href="/auth" className="flex-1">
                    <Button className="w-full bg-gradient-to-r from-violet-600 to-blue-600">
                      Começar Grátis
                    </Button>
                  </Link>
                )}
              </div>
            </nav>
          </div>
        )}
      </header>

      {/* Hero with Prompt Bar */}
      <section className="pt-32 pb-20 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8">
            <Sparkles className="w-4 h-4 text-violet-400" />
            <span className="text-sm text-gray-300">Crie sites com IA em segundos</span>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            O que você quer criar
            <br />
            <span className="bg-gradient-to-r from-violet-400 via-purple-400 to-blue-400 bg-clip-text text-transparent">
              hoje?
            </span>
          </h1>

          <p className="text-xl text-gray-400 mb-12 max-w-2xl mx-auto">
            Descreva sua ideia e deixe a IA construir seu site. Depois, edite como quiser.
          </p>

          {/* Prompt Bar */}
          <div className="relative max-w-2xl mx-auto mb-8">
            <div className="relative group">
              <div className="absolute -inset-0.5 bg-gradient-to-r from-violet-600 to-blue-600 rounded-2xl blur opacity-30 group-hover:opacity-50 transition-opacity" />
              <div className="relative bg-[#0f1117] rounded-2xl border border-white/10 p-2">
                <div className="flex items-center gap-2">
                  <Input
                    type="text"
                    placeholder="Descreva o site que você quer criar..."
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleGenerate()}
                    className="flex-1 bg-transparent border-0 text-white placeholder:text-gray-500 text-lg h-12 focus-visible:ring-0"
                  />
                  <Button
                    onClick={handleGenerate}
                    disabled={!prompt.trim() || isGenerating}
                    className="bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-700 hover:to-blue-700 px-6 h-12"
                  >
                    {isGenerating ? (
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        Gerar
                        <ChevronRight className="w-4 h-4 ml-1" />
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>

            {/* Suggestions */}
            <div className="flex flex-wrap justify-center gap-2 mt-4">
              {suggestions.map((suggestion) => (
                <button
                  key={suggestion}
                  onClick={() => setPrompt(suggestion)}
                  className="px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm text-gray-300 hover:bg-white/10 hover:border-white/20 transition-all"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          </div>

          <p className="text-gray-500 text-sm">
            Gratuitamente. Sem cartão de crédito.
          </p>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20 px-4 bg-[#0f1117]">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit) => (
              <Card key={benefit.title} className="bg-white/5 border-white/10 hover:border-white/20 transition-colors">
                <CardContent className="p-6">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-600/20 to-blue-600/20 flex items-center justify-center mb-4">
                    <benefit.icon className="w-6 h-6 text-violet-400" />
                  </div>
                  <h3 className="text-lg font-semibold mb-2">{benefit.title}</h3>
                  <p className="text-gray-400 text-sm">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section id="como-funciona" className="py-20 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Simples assim
            </h2>
            <p className="text-gray-400">Em três passos você tem seu site pronto</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {steps.map((step) => (
              <div key={step.number} className="relative">
                <div className="text-6xl font-bold text-white/5 mb-4">{step.number}</div>
                <h3 className="text-xl font-semibold mb-2">{step.title}</h3>
                <p className="text-gray-400">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Templates Preview */}
      <section className="py-20 px-4 bg-[#0f1117]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Templates prontos para usar
            </h2>
            <p className="text-gray-400">
              Escolha entre diversos templates profissionalmente desenhados
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { name: "Negócio", color: "from-blue-600 to-cyan-600" },
              { name: "Portfólio", color: "from-purple-600 to-pink-600" },
              { name: "Restaurante", color: "from-orange-600 to-red-600" },
              { name: "Landing Page", color: "from-green-600 to-emerald-600" },
            ].map((template) => (
              <Link key={template.name} href="/templates">
                <div className="group relative aspect-video rounded-xl overflow-hidden bg-white/5 border border-white/10 hover:border-white/20 transition-all cursor-pointer">
                  <div className={`absolute inset-0 bg-gradient-to-br ${template.color} opacity-20 group-hover:opacity-30 transition-opacity`} />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="text-center">
                      <Layout className="w-12 h-12 mx-auto mb-2 text-white/50" />
                      <span className="text-white/70">{template.name}</span>
                    </div>
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-4 left-4 right-4">
                    <span className="text-sm font-medium">{template.name}</span>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="text-center mt-8">
            <Link href="/templates">
              <Button variant="outline" className="border-white/20 hover:bg-white/10">
                Ver todos os templates
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="precos" className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Planos simples
            </h2>
            <p className="text-gray-400">
              Escolha o plano ideal para suas necessidades
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {plans.map((plan) => (
              <Card
                key={plan.name}
                className={`relative bg-white/5 border ${plan.popular ? 'border-violet-500/50' : 'border-white/10'} hover:border-white/20 transition-all`}
              >
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-4 py-1 bg-gradient-to-r from-violet-600 to-blue-600 rounded-full text-xs font-medium">
                    Mais Popular
                  </div>
                )}
                <CardContent className="p-8">
                  <div className="text-center mb-6">
                    <h3 className="text-lg font-medium text-gray-300 mb-2">{plan.name}</h3>
                    <div className="flex items-baseline justify-center gap-1">
                      <span className="text-4xl font-bold">{plan.price}</span>
                      <span className="text-gray-400">{plan.period}</span>
                    </div>
                    <p className="text-sm text-gray-400 mt-2">{plan.description}</p>
                  </div>

                  <ul className="space-y-3 mb-8">
                    {plan.features.map((feature) => (
                      <li key={feature} className="flex items-center gap-3 text-sm">
                        <Check className="w-4 h-4 text-green-400 flex-shrink-0" />
                        <span className="text-gray-300">{feature}</span>
                      </li>
                    ))}
                  </ul>

                  <Link href="/auth">
                    <Button
                      className={`w-full ${plan.popular
                        ? 'bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-700 hover:to-blue-700'
                        : 'bg-white/10 hover:bg-white/20'
                      }`}
                    >
                      {plan.cta}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 bg-gradient-to-b from-[#0f1117] to-[#0a0a0f]">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Pronto para criar?
          </h2>
          <p className="text-gray-400 mb-8">
            Comece gratuitamente e construa seu site em minutos
          </p>
          <Link href="/auth">
            <Button
              size="lg"
              className="bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-700 hover:to-blue-700 px-8"
            >
              Criar meu site grátis
              <ChevronRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 border-t border-white/5">
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-violet-600 to-blue-600 flex items-center justify-center">
                <Sparkles className="w-3 h-3 text-white" />
              </div>
              <span className="font-semibold">Swiftly</span>
            </div>

            <nav className="flex items-center gap-6 text-sm text-gray-400">
              <Link href="#" className="hover:text-white transition-colors">Termos</Link>
              <Link href="#" className="hover:text-white transition-colors">Privacidade</Link>
              <Link href="#" className="hover:text-white transition-colors">Contato</Link>
            </nav>

            <p className="text-sm text-gray-500">
              © 2024 Swiftly. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
