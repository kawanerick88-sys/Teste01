"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Sparkles, Layout, Search, Filter, ArrowLeft, Check, Lock, Loader2, LogOut, Globe } from "lucide-react";

interface Template {
  id: string;
  name: string;
  category: string;
  description: string;
  thumbnail_url: string | null;
  is_premium: boolean;
}

const categories = [
  { id: "all", name: "Todos" },
  { id: "business", name: "Negócio" },
  { id: "portfolio", name: "Portfólio" },
  { id: "landing", name: "Landing Page" },
  { id: "restaurant", name: "Restaurante" },
  { id: "barbershop", name: "Barbearia" },
  { id: "store", name: "Loja" },
  { id: "events", name: "Eventos" },
  { id: "saas", name: "SaaS" },
];

const categoryColors: Record<string, string> = {
  business: "from-blue-600 to-cyan-600",
  portfolio: "from-purple-600 to-pink-600",
  landing: "from-green-600 to-emerald-600",
  restaurant: "from-orange-600 to-red-600",
  barbershop: "from-zinc-600 to-zinc-800",
  store: "from-pink-600 to-rose-600",
  events: "from-indigo-600 to-purple-600",
  saas: "from-violet-600 to-indigo-600",
};

export default function TemplatesPage() {
  const { user, loading: authLoading, signOut } = useAuth();
  const router = useRouter();
  const [templates, setTemplates] = useState<Template[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [useDialogOpen, setUseDialogOpen] = useState(false);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [projectName, setProjectName] = useState("");
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    fetchTemplates();
  }, []);

  const fetchTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from("templates")
        .select("*")
        .eq("is_public", true)
        .order("name");

      if (error) throw error;
      setTemplates(data || []);
    } catch (err) {
      console.error("Error fetching templates:", err);
    } finally {
      setLoading(false);
    }
  };

  const filteredTemplates = templates.filter((template) => {
    const matchesSearch =
      template.name.toLowerCase().includes(search.toLowerCase()) ||
      template.description?.toLowerCase().includes(search.toLowerCase());
    const matchesCategory =
      selectedCategory === "all" || template.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const createProjectFromTemplate = async () => {
    if (!projectName.trim() || !selectedTemplate) return;

    setCreating(true);
    try {
      const { data, error } = await supabase
        .from("projects")
        .insert({
          user_id: user?.id,
          name: projectName,
          template_id: selectedTemplate.id,
          json_state: selectedTemplate.json_schema || {
            blocks: [
              {
                id: "1",
                type: "hero",
                content: {
                  title: projectName,
                  subtitle: "Seu subtítulo aqui",
                  cta: "Saiba mais",
                },
                styles: {},
              },
            ],
          },
          theme_config: {
            colors: {
              primary: "#7c3aed",
              secondary: "#2563eb",
            },
            fonts: {
              heading: "Inter",
              body: "Inter",
            },
          },
        })
        .select()
        .maybeSingle();

      if (error) throw error;

      setUseDialogOpen(false);
      setProjectName("");
      setSelectedTemplate(null);

      if (data) {
        router.push(`/editor/${data.id}`);
      }
    } catch (err) {
      console.error("Error creating project:", err);
    } finally {
      setCreating(false);
    }
  };

  const openUseTemplate = (template: Template) => {
    if (!user) {
      router.push("/auth?redirect=templates");
      return;
    }
    setSelectedTemplate(template);
    setProjectName(template.name);
    setUseDialogOpen(true);
  };

  if (loading || authLoading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      {/* Header */}
      <header className="border-b border-white/5 bg-white/5 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-4">
              <Link href={user ? "/dashboard" : "/"}>
                <Button variant="ghost" size="icon" className="text-gray-300 hover:text-white">
                  <ArrowLeft className="w-5 h-5" />
                </Button>
              </Link>
              <Link href="/" className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-600 to-blue-600 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold text-white">Swiftly</span>
              </Link>
            </div>

            <div className="flex items-center gap-4">
              {user ? (
                <>
                  <Link href="/dashboard">
                    <Button variant="ghost" className="text-gray-300 hover:text-white">
                      Dashboard
                    </Button>
                  </Link>
                  <Button
                    variant="ghost"
                    onClick={() => signOut()}
                    className="text-gray-300 hover:text-white"
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Sair
                  </Button>
                </>
              ) : (
                <Link href="/auth">
                  <Button className="bg-gradient-to-r from-violet-600 to-blue-600">
                    Começar Grátis
                  </Button>
                </Link>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Title */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Biblioteca de Templates</h1>
          <p className="text-gray-400">Escolha um template e comece a editar</p>
        </div>

        {/* Search & Filters */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <Input
              type="text"
              placeholder="Buscar templates..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-10 bg-white/5 border-white/10"
            />
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category.id)}
                className={selectedCategory === category.id
                  ? "bg-gradient-to-r from-violet-600 to-blue-600"
                  : "border-white/10 hover:bg-white/10"
                }
              >
                {category.name}
              </Button>
            ))}
          </div>
        </div>

        {/* Templates Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {filteredTemplates.map((template) => (
            <Card
              key={template.id}
              className="bg-white/5 border-white/10 hover:border-white/20 transition-all group overflow-hidden"
            >
              <CardContent className="p-0">
                {/* Preview */}
                <div className="aspect-video bg-gradient-to-br from-violet-900/20 to-blue-900/20 relative overflow-hidden">
                  <div className={`absolute inset-0 bg-gradient-to-br ${categoryColors[template.category] || "from-gray-600 to-gray-800"} opacity-20`} />
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Layout className="w-16 h-16 text-white/20" />
                  </div>
                  {template.is_premium && (
                    <div className="absolute top-3 right-3 px-2 py-1 rounded-full bg-yellow-500/20 text-yellow-400 text-xs flex items-center gap-1">
                      <Lock className="w-3 h-3" />
                      Pro
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-0.5 rounded-full bg-white/10 text-xs text-gray-400 capitalize">
                      {template.category}
                    </span>
                  </div>
                  <h3 className="font-semibold text-white mb-1">{template.name}</h3>
                  <p className="text-sm text-gray-400 line-clamp-2 mb-4">
                    {template.description || "Template profissional"}
                  </p>

                  <Button
                    onClick={() => openUseTemplate(template)}
                    className="w-full bg-gradient-to-r from-violet-600 to-blue-600 hover:from-violet-700 hover:to-blue-700"
                    disabled={template.is_premium && user?.email !== "admin@swiftly.app"}
                  >
                    {template.is_premium ? (
                      <>
                        <Lock className="w-4 h-4 mr-2" />
                        Usar Template
                      </>
                    ) : (
                      <>
                        <Check className="w-4 h-4 mr-2" />
                        Usar Template
                      </>
                    )}
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredTemplates.length === 0 && (
          <div className="text-center py-16">
            <Layout className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">Nenhum template encontrado</h3>
            <p className="text-gray-400">Tente buscar por outro termo ou categoria</p>
          </div>
        )}
      </main>

      {/* Use Template Dialog */}
      {useDialogOpen && selectedTemplate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <Card className="w-full max-w-md bg-[#0f1117] border-white/10">
            <CardContent className="p-6">
              <h3 className="text-xl font-bold text-white mb-4">Criar projeto</h3>
              <p className="text-gray-400 mb-4">
                Usar template: <span className="text-white">{selectedTemplate.name}</span>
              </p>

              <div className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm text-gray-300">Nome do projeto</label>
                  <Input
                    value={projectName}
                    onChange={(e) => setProjectName(e.target.value)}
                    placeholder="Meu site..."
                    className="bg-white/5 border-white/10"
                  />
                </div>

                <div className="flex gap-3">
                  <Button
                    variant="outline"
                    onClick={() => setUseDialogOpen(false)}
                    className="flex-1 border-white/10"
                  >
                    Cancelar
                  </Button>
                  <Button
                    onClick={createProjectFromTemplate}
                    disabled={!projectName.trim() || creating}
                    className="flex-1 bg-gradient-to-r from-violet-600 to-blue-600"
                  >
                    {creating ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      "Criar projeto"
                    )}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
